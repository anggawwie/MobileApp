import 'package:http/http.dart' as http;

Future<void> main() async {
  await fetchPost();
}

Future<void> fetchPost() async {
  var uri = Uri.https('www.googleapis.com', '/books/v1/volumes', {
    'q': '{http}',
  });

  final response = await http.get(uri);
  print(response.body);
}

class Post {
  String title;
  int userId;
  Post(this.title, this.userId);
}
