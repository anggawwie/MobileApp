void main() {
  const String name = "angga";
  // name = true;
  final int age = 20;
  // age = 25.5;
  bool isCitizen = true;
  isCitizen = false;
  double score = 7.5;
  score = 7;

  print('$name, $age, $isCitizen, $score');

  int? points;
  print(points);
}
