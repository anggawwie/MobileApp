void main() {
  final total = calculateScore(80, 20);
  print('Total Score: $total');
}

int calculateScore(int initialScore, int bonus) {
  return initialScore + bonus;
}
