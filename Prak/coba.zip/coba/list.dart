void main() {
  List<int> number = [1, 2, 3, 4, 5];
  number.add(6);
  print(number);
  print(number[1]);
}
