void main() {
  final greeting = greet(from: 6, name: "angga");
  print(greeting);
}

String greet({String? name, required int from}) {
  return "Hello my name is $name and I'm from $from th avenue";
}
