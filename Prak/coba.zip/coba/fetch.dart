void main() {
  fetchData().then((p) {
    print(p.title);
    print(p.userId);
  });
}

Future<Data> fetchData() {
  const delay = Duration(seconds: 3);

  return Future.delayed(delay, () {
    return Data('test data', 123);
  }); // Future.delayed
}

class Data {
  String title;
  int userId;

  Data(this.title, this.userId);
}
