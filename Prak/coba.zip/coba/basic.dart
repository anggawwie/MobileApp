void main() {
  var name = "angga";

  print('username: $name');

  final age = 20;
  // age = 17;
  const isLogin = true;
  // isLogin = false;

  print('$age, $isLogin');
  print(age + 20);
}
